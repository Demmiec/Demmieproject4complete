(function life() {
  var arrlightboxElements = document.querySelectorAll('.js-lightbox-anchor');
  var ellilightboxItems = document.querySelector('js-lightbox-items');
  var elGallerySearch = document.querySelector('js-lightbox-search");
                                               
   document.lightboxData = document.initialLightboxData= (function getImageData (){
    return Array.prototype.map.call(arrlightboxElements, function (item, index) {
      var image = item.querySelector('.js-lightbox-image');
      
      return{
        url:item.href,
        title: image.title.trim(),
        caption: image.alt.trim()
      };
    });
  })();
  
  /**
  *Event Listeners
  */ 
  elLightboxItems.addEventListener('click,openLightbox, false);
  elGallerySearch.addEventListener('search',filterGallery,false)
  elGallerySearch.addEventListener('keyup',filterGallery, false);
  
 function openLightboxItems.addEventListener('click',openLightbox,false);
  event.preventDefeault();
  var target = event.target;
  
  while
    
    